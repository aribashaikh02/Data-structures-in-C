#include<stdio.h>
int main()
{
     int arr[]={1,4,3,2,1,2,3,5,4};
     int res=0;
     for(int i=0;i<9;i++)
     {
         res= res^arr[i];
     }
     printf("%d",res);
}